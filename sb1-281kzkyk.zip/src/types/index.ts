export interface Fellow {
  id: string;
  name: string;
  cohortYear: number;
  designation: string;
  branch: string;
  year: string;
  imageUrl: string;
  linkedIn: string;
  portfolio: string;
  achievements: string[];
  projects: Project[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  link?: string;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  description: string;
  location: string;
  imageUrl: string;
}