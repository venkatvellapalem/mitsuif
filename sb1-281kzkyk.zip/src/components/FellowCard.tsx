import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, ExternalLink } from 'lucide-react';
import type { Fellow } from '../types';

interface FellowCardProps {
  fellow: Fellow;
}

export function FellowCard({ fellow }: FellowCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transform transition-all hover:scale-105">
      <div className="relative h-48">
        <img
          src={fellow.imageUrl}
          alt={fellow.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900">{fellow.name}</h3>
        <p className="text-sm text-gray-600 mt-1">
          {fellow.designation} • {fellow.branch}
        </p>
        <p className="text-sm text-gray-500 mt-1">Cohort {fellow.cohortYear}</p>
        
        <div className="mt-4 flex space-x-4">
          <a
            href={fellow.linkedIn}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-600 hover:text-indigo-600"
          >
            <Linkedin size={20} />
          </a>
          <a
            href={fellow.portfolio}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-600 hover:text-indigo-600"
          >
            <ExternalLink size={20} />
          </a>
        </div>

        <Link
          to={`/fellows/${fellow.id}`}
          className="mt-4 inline-block px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
        >
          View Profile
        </Link>
      </div>
    </div>
  );
}